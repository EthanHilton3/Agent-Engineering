# Skill Benchmark: grill-me

**Model**: claude-sonnet-5-5 (the test agents)
**Date**: 2026-10-09T23:56:58Z
**Evals**: 0, 1, 2 (3 test prompts, one run of each per configuration; ± is the spread across those 3)

## Summary

| Metric | With Skill | Without Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 100% ± 0% | 81% ± 9% | +0.19 |
| Time | 32.1s ± 4.1s | 41.6s ± 0.6s | -9.5s |
| Tokens | 61850 ± 4724 | 69339 ± 4107 | -7490 |